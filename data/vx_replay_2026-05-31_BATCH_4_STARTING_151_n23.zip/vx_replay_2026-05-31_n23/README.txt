vX Replay Tagger Bundle
Exported: 2026-05-31T03:42:03.420Z
Events:   23

events.csv — full tagged event log
screenshots/ — chart screenshots, named event_NNN_signal.jpg / event_NNN_outcome.jpg

Send this entire ZIP to Claude for batch review.
